<div class="footer pt-20">

		
						&copy; 2016 Portrait <a href="" target="_blank">PORTRAIT</a>&nbsp;&nbsp;&nbsp;&bull;&nbsp;&nbsp;&nbsp;Version - 1.0.0
					
					</div>
					</div>