	<div class="sidebar sidebar-main hidden-xs">
	<div class="sidebar-content">

		<!-- User menu -->
		<div class="sidebar-user">
			<div class="category-content">
				<div class="media">
					<a href="index.php" class="media-left"><img src="assets/images/users/user6.png" class="img-circle img-sm" alt=""></a>
					<div class="media-body">
						<span class="media-heading text-semibold">Andrew Brewer</span>
						
					</div>

					<div class="media-right media-middle">
						<ul class="icons-list">
							<li>
								<a href="login_simple.htm"><i class="fa fa-sign-out"></i></a>
							</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- /user menu -->

		<!-- Main navigation -->
		<div class="sidebar-category sidebar-category-visible">
			<div class="category-content no-padding">
				<ul class="navigation navigation-main navigation-accordion">
					
					<!-- Main -->					
					<li class="active">
						<a href=""><i class="fa fa-desktop"></i> <span>Dashboard</span></a>						
					</li>																			
					<!-- /Main -->	
					
					<!-- Content -->
					<li class="navigation-header"><span>Content</span> <i class="fa fa-bars" title="Content"></i></li>
					<li>
						<a href="#"><i class="fa fa-th"></i> <span>BOOKS</span></a>
						<ul>
							<li><a href="list_book.php">LIST BOOK</a></li>
							<li><a href="add_book.php">ADD BOOK</a></li>
												
						</ul>
					</li>
				<li>
						<a href="#"><i class="fa fa-th"></i> <span>CLASSES</span></a>
						<ul>
							<li><a href="list_class.php">LIST CLASS</a></li>
							<li><a href="add_class.php">ADD Class</a></li>
												
						</ul>
					</li>
						<li>
						<a href="#"><i class="fa fa-th"></i> <span>SUBJECT</span></a>
						<ul>
							<li><a href="list_sub.php">LIST SUBJECT</a></li>
							<li><a href="add_sub.php">ADD SUBJECT</a></li>
												
						</ul>
					</li>
						<li>
						<a href="#"><i class="fa fa-th"></i> <span>INSTITUTE</span></a>
						<ul>
							<li><a href="list_school.php">LIST INSTITUTE</a></li>
							<li><a href="add_school.php">ADD INSTITUTE </a></li>
												
						</ul>
					</li>
				
						<li>
						<a href="#"><i class="fa fa-th"></i> <span>SCHOOL BOOKS</span></a>
						<ul>
							<li><a href="listschoolbooks.php"> LIST SCHOOL BOOKS</a></li>
							<li><a href="#">ADD (ASSIGN) SCHOOL BOOKS</a></li>
												
						</ul>
					</li>
					
					<li>
						<a href="#"><i class="fa fa-paper-plane"></i> <span>SETTING</span></a>
						<ul>
							<li><a href="#">PROFILE UPDATE</a></li>							
							<li><a href="password.php">PASSWORD UPDATE</a></li>										
							<li><a href="#">WEBSITE UPDATE</a></li>				
							
						</ul>
					</li>													
					
					
					
					
					
					
					
				</ul>
			</div>
		</div>
		<!-- /main navigation -->

	</div>
	</div>